My search engine allows users to search for specific words and provides a list of pages that include those words. The frequency with which the provided word appears on the page is used to rank the pages.
Technologies used in this project are as follows:
1) Python as coding language
2) Visual Studio Code as IDE
3) MongoDB as my database
4) Flask as my framework and to interact with user
5) Libraries used are : pandas, pymongo, bs4, lxml, flask

Static Data: 
    myPath: This is a string that contains the path to the webpages that will be crawled for information and then parsed used beautiful soap. 
    links: These links are random websites which are contained within the directory and then stored in mongodb. 
    stopWords: This is a list of stop words that do not contribute to the meaning of a document.

Methods: 
    - crawler: This function web crawls the websites i pass them in them while . 
    - parseText: Eliminates punctuation and non-alphabet letters from a string, separates it into individual words, and removes stop words. It yields a list of words. 
    - createRank: This method builds and returns a dictionary from a list of words. It employs words as keys and the frequency with which the word appears in the input list as values.

Data Structures:
    - Hashmap: I created a hashmap data structure that contains the character or substring within a given word
            a link to its parent node, a dictionary containing the children of a given node
            a boolean identifier representing whether the node is a prefix or not, a boolean identifier representing whether the node is an indexTerm or not
            an occurence list represented by a dictionary, and a redundant rank list represented by a dictionary. URL titles are used as values in the rank list, and the frequency with which the index phrase appears in the file is used as a value. URL title and description are used as keys in the occurrence list, and a list of found description or most matching description is used as the value. The order represents the frequency with which the index phrase appears in each of the value list's links.

    - Arraylist: I constructed a arraylist data structure with only one property, a connection to its root node whose has been found in mongodb as the most closest search. I wrote an  method
                that extracts all of the search results required render the html template with proper results within the arraylist and initiates all of the index term's properties such as isIndexTerm, rank, and occurenceList.

Working of Serarch Engine:
    - I created a search engine using python, mongodb and flask as framework. I installed required libraries and then started building functions to web crawl and search specific keywords
    - Following are the methods used in my search engine
    testing.py:(stackoverflow.py) to test a wbesite for response and dump it into json.
    crawler.py: the main backend of the my search engine which crawls through the websitee saves it in the mongodb and then use ranking from mongo dba nd store it in the array list and pass it to the templates.
    app.py: which is supported by flask frame work and uses basic html templates to render output and request input from the user. it has two routes home and search_results respectively. This queries into the database and requests crawlers to return a arraylist using a hash map ranking defined in crawler.py
    - FInally the user can access the website via any supported browser and run the application using. Enter the keyword find the best results including the output.csv file for particular keyword.


Main Function: 
    - The main objective of my project is to create a search which will take an input from a user and give desired output. 
    - For this, web crawling is required to save the data that can be used for searching
    - ranking using hashmap is involved so thaat the best results are listed first
    - hosting a flask server where user can interact with the search enigine endlessly having produced user's desired output.
    - arraylist has been rendered accrodingly and sent as an output for html template

Execution - 
    pip install -r requirements.txt
    python crawler.py
    python app.py
